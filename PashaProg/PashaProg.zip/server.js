function allMesseges(){
	return messeges;
}

var messeges = [{
	"text": "This is first messege!",
},{
	"text": "This is second messege!",
}, {
	"text": "This is third messege!"
}];